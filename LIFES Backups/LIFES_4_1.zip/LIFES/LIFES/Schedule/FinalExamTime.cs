﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIFES.Schedule
{
    /*
     * Class Name: FinalExamTime.cs
     * Author: Scott Smoke
     * Date: 3/25/2015
     * Modified by: Scott Smoke
     * This class is the final exam times that
     * are constructed after the scheduler has ran.
     */ 
    class FinalExamTime
    {
    }
}
