﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LIFES;
using System.Collections;
namespace LIFES.Schedule
{
    class Scheduler
    {
        private TimeConstraints tc;
        //compressed data
        /*
         * This will construct a schedule object that will schedule the final 
         * exams
         * 
         * 
         * Author: Scott Smoke
         * Modified by: Scott Smoke
         * 
         */
        public Scheduler(TimeConstraints t)
        {
            tc = t;

            //to do 
        }

     
        /*
         * This will reschedule the final exams once a user has pressed 
         * the reschedule button.
         * 
         * Author: Scott Smoke
         * Modified by: Scott Smoke 
         * 
         */
        public void reSchedule()
        {
            //to do
        }

        
    }
}
