﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIFES.Authentication
{
    class Authentication
    {
    }

    class User 
    { 
    }

    class Encryption
    {
    }
}
